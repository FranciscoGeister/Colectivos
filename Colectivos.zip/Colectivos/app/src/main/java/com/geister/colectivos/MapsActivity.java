package com.geister.colectivos;

import android.content.pm.PackageManager;
import android.location.Location;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocompleteFragment;
import com.google.android.gms.location.places.ui.PlaceSelectionListener;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.CustomCap;
import com.google.android.gms.maps.model.JointType;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.maps.model.RoundCap;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import static android.provider.Contacts.SettingsColumns.KEY;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    //variables para permisos de ubicación
    private boolean mLocationPermissionGranted;
    private static final int PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 1;
    //variable con la última ubicación conocida
    private Location mLastKnownLocation;
    private CameraPosition mCameraPosition;
    private FusedLocationProviderClient mFusedLocationProviderClient;
    // A default location (Sydney, Australia) and default zoom to use when location permission is
    // not granted.
    private final LatLng mDefaultLocation = new LatLng(-33.8523341, 151.2106085);
    private static final int DEFAULT_ZOOM = 15;
    private static final String TAG = MapsActivity.class.getSimpleName();

    //para las polilineas
    private static final int COLOR_BLACK_ARGB = 0xff000000;
    private static final int POLYLINE_STROKE_WIDTH_PX = 12;

    //private EditText address;
    private Button ruta;
    private String destination;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        //address = (EditText) findViewById(R.id.address);
        ruta = (Button) findViewById(R.id.ruta);
        ruta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuilder sbDirections, sbAddress;
                Object[] dataTransferDirections = new Object[2];
                Object[] dataTransferAddress = new Object[2];


                sbDirections = new StringBuilder();
                sbDirections.append("https://maps.googleapis.com/maps/api/directions/json?");
                sbDirections.append("origin=" + mLastKnownLocation.getLatitude() + "," + mLastKnownLocation.getLongitude());
                sbDirections.append("&destination=-36.82797,-73.066288");
                sbDirections.append("&mode=walking");
                sbDirections.append("&key=" + "AIzaSyD9Y9AiU9GJEYaviLLxMEvjYfv-EsKgpf0");

                GetDirectionsData getDirectionsData = new GetDirectionsData(getApplicationContext());
                dataTransferDirections[0] = mMap;
                dataTransferDirections[1] = sbDirections.toString();
                //dataTransfer[2] = new LatLng(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude());
                //dataTransfer[3] = new LatLng(-36.826604, -73.063093);

                getDirectionsData.execute(dataTransferDirections);

                sbAddress = new StringBuilder();
                sbAddress.append("https://maps.googleapis.com/maps/api/geocode/json?");
                sbAddress.append("address=" + destination);
                sbAddress.append("&key=" + "AIzaSyD9Y9AiU9GJEYaviLLxMEvjYfv-EsKgpf0");

                GetGeocodingData getGeocodingData = new GetGeocodingData(getApplicationContext());
                dataTransferAddress[0] = mMap;
                dataTransferAddress[1] = sbAddress.toString();

                getGeocodingData.execute(dataTransferAddress);

                Polyline polyline1 = mMap.addPolyline(new PolylineOptions()
                        .clickable(true)
                        .add(
                                new LatLng(-36.82696, -73.06913),
                                new LatLng(-36.8284, -73.06749),
                                new LatLng(-36.82797, -73.0662),
                                new LatLng(-36.826624, -73.06309),
                                new LatLng(-36.82855, -73.06185),
                                new LatLng(-36.82860, -73.06162),
                                new LatLng(-36.82685, -73.057314)));
                // Store a data object with the polyline, used here to indicate an arbitrary type.
                polyline1.setTag("colectivo 10");
                // Style the polyline.
                stylePolyline(polyline1);

            }
        });

        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        /*
        obtiene el SupportMapFragment (definido en el activity_maps.xml) y es notificado
        cuando el mapa esta listo para usar
        */
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        //para registrar el callback del mapa
        mapFragment.getMapAsync(this);

        /*
        //autocomplete
        PlaceAutocompleteFragment autocompleteFragment = (PlaceAutocompleteFragment)
                getFragmentManager().findFragmentById(R.id.place_autocomplete_fragment);
        //restingir el autocomplete a Concepcion
        autocompleteFragment.setBoundsBias(new LatLngBounds(
                new LatLng(-37.02583151932976, -73.212164658635),
                new LatLng(-36.583807508197495, -72.8372562113693)));


        autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(Place place) {
                // TODO: Get info about the selected place.
                destination = place.getName().toString();
                Log.i(TAG, "An error occurred: " + destination);
            }

            @Override
            public void onError(Status status) {
                // TODO: Handle the error.
                Log.i(TAG, "An error occurred: " + status);
            }
        });
        */

    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        /*
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
        */

        /*
        // Add polylines to the map.
        // Polylines are useful to show a route or some other connection between points.

        Polyline polyline1 = googleMap.addPolyline(new PolylineOptions()
                .clickable(true)
                .add(
                        new LatLng(-36.82696, -73.06913),
                        new LatLng(-36.8284, -73.06749),
                        new LatLng(-36.82797, -73.0662),
                        new LatLng(-36.826624, -73.06309),
                        new LatLng(-36.82855, -73.06185),
                        new LatLng(-36.82860, -73.06162),
                        new LatLng(-36.82685, -73.057314)));
        // Store a data object with the polyline, used here to indicate an arbitrary type.
        polyline1.setTag("colectivo 10");
        // Style the polyline.
        stylePolyline(polyline1);
        */



        // Prompt the user for permission.
        getLocationPermission();

        // Turn on the My Location layer and the related control on the map.
        updateLocationUI();

        // Get the current location of the device and set the position of the map.
        getDeviceLocation();

    }

    //método para obtener la ubicacion
    private void getDeviceLocation() {
        /*
         * Get the best and most recent location of the device, which may be null in rare
         * cases when a location is not available.
         */
        try {
            if (mLocationPermissionGranted) {
                Task<Location> locationResult = mFusedLocationProviderClient.getLastLocation();
                locationResult.addOnCompleteListener(this, new OnCompleteListener<Location>() {
                    @Override
                    public void onComplete(@NonNull Task<Location> task) {
                        if (task.isSuccessful()) {
                            // Set the map's camera position to the current location of the device.
                            mLastKnownLocation = task.getResult();
                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(
                                    new LatLng(mLastKnownLocation.getLatitude(),
                                            mLastKnownLocation.getLongitude()), DEFAULT_ZOOM));
                        } else {
                            Log.d(TAG, "Current location is null. Using defaults.");
                            Log.e(TAG, "Exception: %s", task.getException());
                            mMap.moveCamera(CameraUpdateFactory
                                    .newLatLngZoom(mDefaultLocation, DEFAULT_ZOOM));
                            mMap.getUiSettings().setMyLocationButtonEnabled(false);
                        }
                    }
                });
            }
        } catch (SecurityException e)  {
            Log.e("Exception: %s", e.getMessage());
        }
    }

    /**
     * Prompts the user for permission to use the device location.
     */
    //método para dar mensaje de permiso de ubicación (runtime) al usuario
    private void getLocationPermission() {
        /*
         * Request location permission, so that we can get the location of the
         * device. The result of the permission request is handled by a callback,
         * onRequestPermissionsResult.
         */
        if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mLocationPermissionGranted = true;
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
        }
    }

    //método que maneja el resultado del permiso de ubicación
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[],
                                           @NonNull int[] grantResults) {
        mLocationPermissionGranted = false;
        switch (requestCode) {
            case PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    mLocationPermissionGranted = true;
                }
            }
        }
        updateLocationUI();
    }

    //método que pone los controles de localización en el mapa
    private void updateLocationUI() {
        if (mMap == null) {
            return;
        }
        try {
            if (mLocationPermissionGranted) {
                mMap.setMyLocationEnabled(true);
                mMap.getUiSettings().setMyLocationButtonEnabled(true);
            } else {
                mMap.setMyLocationEnabled(false);
                mMap.getUiSettings().setMyLocationButtonEnabled(false);
                mLastKnownLocation = null;
                getLocationPermission();
            }
        } catch (SecurityException e)  {
            Log.e("Exception: %s", e.getMessage());
        }
    }

    /**
     * Styles the polyline, based on type.
     * @param polyline The polyline object that needs styling.
     */
    private void stylePolyline(Polyline polyline) {
        polyline.setStartCap(new RoundCap());
        polyline.setEndCap(new RoundCap());
        polyline.setWidth(POLYLINE_STROKE_WIDTH_PX);
        polyline.setColor(COLOR_BLACK_ARGB);
        polyline.setJointType(JointType.ROUND);
    }
}
